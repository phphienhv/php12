<?php
for($i = 0; $i < 5; $i ++) {
    for($j = (5 - $i); $j < 5; $j ++) {
        echo "*";
    }
    echo "<br>";
}
for($i = 0; $i < 5; $i ++) {
    for($j = (5 - $i); $j < 5; $j ++) {
        echo "A+";
    }
    echo "<br>";
}
?>