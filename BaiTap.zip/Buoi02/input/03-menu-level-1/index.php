<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
   <head>
   <?php include_once('html/head.php');  ?>
   </head>
   <body>
      <?php include_once('html/menu.php'); ?>
      <?php include_once('html/breadcrumb.php'); ?>
      <h3>Home</h3>
   </body>
</html>