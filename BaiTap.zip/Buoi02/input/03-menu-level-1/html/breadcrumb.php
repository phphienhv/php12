<div class="breadcrumb">
    <a href="index.php">Home</a>
    <span>></span>
    <span>About</span>
</div>